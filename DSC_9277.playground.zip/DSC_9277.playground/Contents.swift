//import UIKit
//func bmiCalc(personHeight : Double, personWeight : Double) ->Double{
//    let bmiPer = personWeight / pow(personHeight, 2)
//
//   if bmiPer > 25
//   {
//    print ("You are over weight")
//
//    }
//   else if bmiPer < 18 {
//    print ("you are underweight")
//    }
//   else {
//    print ("you are in normal weight")
//    }
//    return bmiPer
//}
//
//
//bmiCalc(personHeight: 1.82, personWeight: 82.75)
//// weight showing how much should i reduce or gain
//
import UIKit

func bmi(personHeight: Double, personWeight: Double) ->String
{
    let perBmi = personWeight / pow(personHeight, 2)
    let shortenedBmi = String(format: "%0.2f", perBmi)
    var interpretation = ""
    var goodWeight : Double

    if perBmi > 25{
        //let goodWeight : Double
        goodWeight = 25 * pow(personHeight, 2)
       // let shortenedGoodWeight = String(format: "%0.02f", goodWeight)
        let howMuchKilos = personWeight - goodWeight
        //let shortenedHowMuchKilos = String(format: "%0.02f", howMuchKilos)
        interpretation = "you are overweight. Your weight should be less than \(goodWeight) Kindly stay motivated to reduce \(howMuchKilos)"
        }
    else if perBmi < 18{
        //let wrightWeight : Double
        goodWeight = 18.5 * pow(personHeight, 2)
        //let shortenedWrightweight = String(format: "%0.02f", wrightWeight)
        let howMuchKilos = personWeight + goodWeight
        //let shortenedHowManyKilos = String(format: "%0.02f", howManyKilos)
        interpretation = "you are underweight. Your weight should be above \(goodWeight) Kindly try to gain \(howMuchKilos)"
        
    }
    else {
        interpretation = "you are Perfectly normal Weight. Nourish yourself Contently!! "
    }
    return("Your Bmi is \(shortenedBmi) and \(interpretation)")

//    else if perBmi > 18{
//
//    }

}
bmi(personHeight: 1.68, personWeight: 94)

